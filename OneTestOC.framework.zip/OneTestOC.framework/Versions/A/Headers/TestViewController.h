//
//  TestViewController.h
//  OneTestOC
//
//  Created by linming on 2022/8/22.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface TestViewController : UIViewController
+ (void) printTest;


@end

NS_ASSUME_NONNULL_END
